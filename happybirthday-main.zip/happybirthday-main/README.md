# Build Webpage Happy Birthday with HTML, CSS, and JS
### [Watch it on youtube](https://www.youtube.com/watch?v=SnNeoBlJQ3U)
![preview img](https://user-images.githubusercontent.com/71541409/224200468-49a15829-c4b7-4e09-80e1-08ce48eca786.png)
